<?php
CheckAdmin($admin_user,$admin_level);
?>
<body>
	<TABLE cellSpacing="0" cellPadding="0" width="820" border="0">
      <TBODY>
        <TR>
          <TD width="10" vAlign=top><IMG src="images/fader.gif" border=0></TD>
          <TD width="940" vAlign=top><IMG src="images/topfader.gif" border=0><BR>
		  <!-- Admin -->
		  &nbsp;&nbsp;<IMG SRC="images/admin/textmenu_admin.gif" BORDER="0"><BR>
				<TABLE width="940" align=center cellSpacing=0 cellPadding=0 border=0>
				<TR>
					<TD height="1" class="dotline"></TD>
				</TR>
				<TR>
					<TD>
 <br>
<br>
 <br><center>
<table width="500" align="center" cellSpacing="3" cellPadding="2" border="0" >
<tr>
<td align="center"><a href="index.php?naivoi=admin&voi=backup"><img src="images/admin/data.png" border="0"><br>Backup ข้อมูลเวป</a></td>
<td align="center"><a href="index.php?naivoi=admin&voi=backupdb"><img src="images/admin/db.png" border="0"><br>Backup ฐานข้อมูล</a></td>
</tr>
</table>
<br>
<br>
<br>
</td>
</tr>
</table>
				</TD>
				</TR>
			</TABLE>