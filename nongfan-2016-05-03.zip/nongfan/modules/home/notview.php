<?php
notview();
?>