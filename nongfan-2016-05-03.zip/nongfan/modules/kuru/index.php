<?php
 //notview();
   echo "<br>กำลังพัฒนา....";
   echo "<br><br><br><br><br><br><br><br><br><br><br><br><br>";
?>