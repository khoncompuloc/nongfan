<?php 
 CheckUser_Nopwd($login_true);
 empty($_SESSION['section_id'])?$section_id="":$section_id=$_SESSION['section_id'];	
 empty($_SESSION['admin_level'])?$admin_level="":$admin_level=$_SESSION['admin_level'];	 
 empty($ProcessOutput)?$ProcessOutput="":$ProcessOutput=$ProcessOutput ;	
?>
<link href="modules/wsd/css/style.css" rel="stylesheet" type="text/css">
<!--
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/template_css.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery1.3.2.js"></script>
-->
					
<script language="javascript" type="text/javascript">
function suggest(inputString){
        var section_id = document.search_name.section_id.value ;
		//alert(section_id) ;
		if(inputString.length == 0) {
			$('#suggestions').fadeOut();
		} else {
		$('#sh_name').addClass('load');
			$.post("modules/wsd/suggest_st_search.php", {queryString: ""+inputString+"" ,section_id: ""+section_id+""}, function(data){
				if(data.length >0) {
					$('#suggestions').fadeIn();
					$('#suggestionsList').html(data);
					$('#sh_name').removeClass('load');
				}
			});
		}
	}
	
function fill(thisValue) {
		$('#sh_name').val(thisValue);
		setTimeout("$('#suggestions').fadeOut();", 300);
	}

function Inint_AJAX() {
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
};

function dochange(src, val) {
     //alert("s0");
     var req = Inint_AJAX();
     req.onreadystatechange = function () { 
          if (req.readyState==4) {
		           
               if (req.status==200) {
			        
                    document.getElementById(src).innerHTML=req.responseText; //รับค่ากลับมา
					//document.querySelector(#src).innerHTML=req.responseText; //รับค่ากลับมา
               } 
          }
     };
	 var random=Math.random()
     req.open("GET", "modules/wsd/stocktype.php?data="+src+"&val="+val+"&random="+random , true); //สร้าง connection
     req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); // set Header
     req.send(null); //ส่งค่า
}
 
function  print_acc_Open(sh_id) {
window.open("?folder=wsd&file=print_acc_see&sh_id="+sh_id+"","","toolbar=no,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=950,height=680,left=5,top=5"); 
}  


window.onLoad=dochange('stock_type', -1); 
</script>

<table width="100%" border="0" cellspacing="1" cellpadding="2" >
    <tr>
    <td width="100%" align="left" colspan="2"><img src="images/wsd/texmenu_stock_requis.gif" width="170" height="32" align="baseline"></td>
    </tr>
    <tr>
    <td height="1" class="dotline" colspan="2" width="100%"><br></td>
    </tr>		
    <tr>
    <td width="40%">
    <form NAME="search_name" METHOD="post" ACTION="?compu=wsd&loc=index&op=search_name" onSubmit="return check_name()" ENCTYPE="multipart/form-data" >
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#DDDDDD">
       <tr>
       <td align="center" valign="middle"><br>
               ชื่อหรือชนิดวัสดุ :&nbsp;
	   <input type="text" size="28" value="" name="sh_name" id="sh_name" onkeyup="suggest(this.value);" onblur="fill();" class="" />
       <div class="suggestionsBox_search" id="suggestions" style="display: none;"><img src="images/car/arrow.png" style="position: relative; top: -12px; left: 40px;" alt="upArrow" />
       <div class="suggestionList_search" id="suggestionsList"></div>
       </div><br><br> 
	 <?php 
	 if($section_id == 0 OR $admin_level == 2) {
	      $Vsection_id = 0 ;
	 } else {
	      $Vsection_id = $_SESSION['section_id'] ;
	 }
	 
	 ?>
      <input type="hidden" value="<?php echo $Vsection_id ;?>" name="section_id" id="section_id" /> 	 
	  <input type="submit" name="submit" id="submit" value="ค้นหาตามชื่อ" />
	
       </td>

       </tr>
       </table>
       </form>   
    </td>
    <td width="60%">
       <form NAME="search_type" METHOD="post" ACTION="?compu=wsd&loc=index&op=search_type" onSubmit="return check_type()" ENCTYPE="multipart/form-data" >
       <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#999999">
       <tr>
       <td align="center" height="35" valign="middle"><br>
          ประเภทวัสดุ :<font id="stock_type"><select><option value="0">-------------------</option></select></font>&nbsp;
          ย่อย :<font id="stock_subtype"><select><option value="0">-------------------</option></select></font><br><br>    
          <input type="submit" name="submit" id="submit" value="ค้นหาตามประเภท" />      
       </td>
       </tr>
       </table>
       </form>		     
    </td>
    </tr>
</table>

<SCRIPT LANGUAGE="javascript">	
	
function check_name() {
if(document.search_name.sh_name.value=="") {
alert("กรุณากรอกชื่อวัสดุด้วยครับ") ;
document.search_name.sh_name.focus() ;
return false ;
}
else 
return true ;
}	

function check_type() {
if(document.search_type.type_id.selectedIndex==0) {
alert("กรุณาเลือกประเภทวัสดุด้วยครับ") ;
document.search_type.type_id.focus() ;
return false ;
}
else 
return true ;
}		

</SCRIPT>

<?php 
if($op == "search_name" or $op == "search_type"){
	 empty($_POST["type_id"])?$typeid="":$typeid=$_POST["type_id"] ;
     empty($_POST["subtype_id"])?$subtypeid="":$subtypeid=$_POST["subtype_id"] ;
	 	
	$db->connectdb(DB_NAME,DB_USERNAME,DB_PASSWORD);
?>
 
 <table width="100%" cellspacing="2" cellpadding="1" >
  <tr bgcolor="#0066FF" height="20">
   <td width="33%"><CENTER><font color="#FFFFFF"><B>ชื่อหรือชนิดวัสดุ (ขนาดหรือลักษณะ)</B></font></CENTER></td>
   <td width="18%"><CENTER><font color="#FFFFFF"><B>ประเภท</B></font></CENTER></td>
   <td width="18%"><CENTER><font color="#FFFFFF"><B>ย่อย</B></font></CENTER></td>
   <td width="10%"><CENTER><font color="#FFFFFF"><B>จำนวนเหลือ</B></font></CENTER></td>  
   <td width="10%"><CENTER><font color="#FFFFFF"><B>หน่วยนับ</B></font></CENTER></td>     
   <td width="11%"><CENTER><font color="#FFFFFF"><B>หน่วยงาน</B></font></CENTER></td>
  </tr>  
<?php 
if($op == "search_name") {
$res['stock_head'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD." WHERE sh_name='".$_POST['sh_name']."' ORDER BY sh_id DESC "); //LIMIT $goto, $limit 
}
if($op == "search_type") {
   if($subtypeid == "") {
       $res['stock_head'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD." WHERE type_id=".$typeid." ORDER BY sh_name "); //LIMIT $goto, $limit   
   } else {
       $res['stock_head'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD." WHERE type_id=".$typeid." AND subtype_id=".$subtypeid." ORDER BY sh_name "); //LIMIT $goto, $limit 
   }
}
$count=0;
while($arr['stock_head'] = $db->fetch($res['stock_head'])){
    empty($arr['stock_head']['sh_diff_name'])?$sh_diff_name="":$sh_diff_name=" ( ".$arr['stock_head']['sh_diff_name']." )" ;	
	$res['stock_type'] = $db->select_query("SELECT * FROM ".TB_STOCK_TYPE." WHERE type_id='".$arr['stock_head']['type_id']."' ");
	$arr['stock_type'] = $db->fetch($res['stock_type']);
	$res['stock_subtype'] = $db->select_query("SELECT * FROM ".TB_STOCK_SUBTYPE." WHERE subtype_id='".$arr['stock_head']['subtype_id']."' ");
	$arr['stock_subtype'] = $db->fetch($res['stock_subtype']);
	empty($arr['stock_subtype']['subtype_name'])?$subtype_name="":$subtype_name=$arr['stock_subtype']['subtype_name'] ;	

    if($count%2==0) { //ส่วนของการ สลับสี 
      $ColorFill = "#FDEAFB";
    } else {
      $ColorFill = "#F0F0F0";
    }

    $res['stock_head_section'] = $db->select_query("SELECT shs_id ,section_id FROM ".TB_STOCK_HEAD_SECTION." WHERE sh_id='".$arr['stock_head']['sh_id']."' AND section_id='".$section_id."'");
	$rows['stock_head_section'] = $db->rows($res['stock_head_section']); 
		if($rows['stock_head_section']){	
    $arr['stock_head_section'] = $db->fetch($res['stock_head_section']);	
    $res['stock_head_price'] = $db->select_query("SELECT SUM(shp_amountcost) AS amountcost  FROM ".TB_STOCK_HEAD_PRICE." WHERE shs_id=".$arr['stock_head_section']['shs_id']."");
	$arr['stock_head_price'] = $db->fetch($res['stock_head_price']);
	$res['member_section'] = $db->select_query("SELECT section_name  FROM ".TB_MEMBER_SECTION." WHERE section_id=".$arr['stock_head_section']['section_id']."");
	$arr['member_section'] = $db->fetch($res['member_section']);

?>
    <tr bgcolor="<?php echo $ColorFill; ?>" onmouseover="this.style.backgroundColor='#FFF0DF'" onmouseout="this.style.backgroundColor='<?php echo $ColorFill;?>' " height="18">

     <td><A HREF="?compu=wsd&loc=requistion&op=requist_form&sh_id=<?php echo $arr['stock_head']['sh_id'];?>">
	 <?php echo $arr['stock_head']['sh_name'];?><?php echo $sh_diff_name ;?></A><?php //echo $CommentIcon;?></td>
     <td align="center"><?php echo $arr['stock_type']['type_name'] ;?></td>
	 <td align="center"><?php echo $subtype_name ;?></td>
     <td align="center"><?php echo $arr['stock_head_price']['amountcost'] ;?></td>
     <td align="center"><?php echo $arr['stock_head']['sh_unit'] ;?></td>
	 <td align="center"><?php echo $arr['member_section']['section_name'] ;?></td>
    </tr>
	<TR>
		<TD colspan="6" height="1" class="dotline"></TD>
	</TR>
<?php 
	$count++;
	}
 } 
?>
 </table>
<BR>
<?php 
//	SplitPage($page,$totalpage,"?folder=admin&file=stock");
//	echo $ShowSumPages ;
//	echo "<BR>";
//	echo $ShowPages ;

$db->closedb ();

} else if($op == "requist_form" AND $action == "add_ok") {

	        $db->connectdb(DB_NAME,DB_USERNAME,DB_PASSWORD);
            $sd_logic = 0 ; 
            $sd_print = 0 ;	
            $sd_pricesum = $_POST['sd_price']*$_POST['sd_amount'] ;			
			
            $res['head_from_amountcost'] = $db->select_query("SELECT SUM(shf_amountcost) AS amountcost ,SUM(shf_price*shf_amountcost) AS pricecost  FROM ".TB_STOCK_HEAD_PRICE." WHERE sh_id=".$_POST['sh_id']."");
	        $arr['head_from_amountcost'] = $db->fetch($res['head_from_amountcost']);			
			$sd_amountcost = $arr['head_from_amountcost']['amountcost'] - $_POST['sd_amount'] ;
			$sd_pricecost =  $arr['head_from_amountcost']['pricecost'] - $sd_pricesum ;
			
            $db->add_db(TB_STOCK_SECTION.$budget,array(
				"sh_id"=>"".$_POST['sh_id']."",
				"sd_date"=>"".$_POST['sd_date']."",
				"sd_name"=>"".$_POST['sd_name']."",
				"sd_price"=>"".$_POST['sd_price']."",
				"sd_amount"=>"".$_POST['sd_amount']."",
				"sd_amountcost"=>"".$sd_amountcost."",
				"sd_pricecost"=>"".$sd_pricecost."",
				"sd_note"=>"".$_POST['sd_note']."",				
				"sd_logic"=>"".$sd_logic."",								
				"sd_print"=>"".$sd_print."",												
				"section_id"=>"".$_POST['section_id']."",	
                "shf_id"=>"".$_POST['shf_id'].""				
			));	
			
			$db->update_db(TB_STOCK_HEAD_PRICE,array(
				"shf_amountcost"=>"".$_POST['shf_amountcost'].""
				)," shf_id='".$_POST['shf_id']."' ");
         		   
			
			$db->closedb ();
			echo  "<BR><BR>";
			echo  "<CENTER><A HREF=\"?folder=admin&file=main\"><IMG SRC=\"images/login-welcome.gif\" BORDER=\"0\"></A><BR><BR>";
			echo  "<FONT COLOR=\"#336600\"><B>ได้ทำการบันทึกเบิกวัสดุของคุณ  ".$_POST['sd_name']." เรียบร้อยแล้ว</B></FONT><BR><BR>";
			echo  "<BR><BR>";
			echo  "<input type=\"button\" onClick=\"print_acc_Open(".$_POST['sh_id'].")\" value=\"ดูบัญชีวัสดุ  ".$_POST['sh_name']."\">";
			echo  "</CENTER>";	
	        echo  "<BR><BR>";


} else if($op == "requist_form" AND $action == "add") {

	    $db->connectdb(DB_NAME,DB_USERNAME,DB_PASSWORD);
		

        $res['member'] = $db->select_query("SELECT * FROM ".TB_MEMBER." WHERE member_id=".$_POST['member_id']."");	
	    $arr['member'] = $db->fetch($res['member']);		
		
		$sh_id = $_POST['sh_id'] ;
		$sd_date = $_POST['sh_date_1'] ;
		$sd_name = $arr['member']['fname'] ;
		$sd_amount = $_POST['sd_amount'] ;
		$sh_name = $_POST['sh_name'] ;
		$sh_unit = $_POST['sh_unit'] ;
		$sd_note = $_POST['sd_note'] ;               
        //$section_id = $arr['member']['section_id'] ;

        $arr_date = explode("-",$sd_date) ;
        $day = $arr_date[2] ;
		$month = $FULL_MONTH[$arr_date[1]] ;
		$year = $arr_date[0]+543 ;

		$shf_id = $_POST['shf_id'] ;
        $res['stock_head_form'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD_PRICE." WHERE shf_id=".$shf_id."");	
	    $arr['stock_head_form'] = $db->fetch($res['stock_head_form']);
		$shf_amountcost = $arr['stock_head_form']['shf_amountcost'] - $sd_amount ;
		
        $res['member_section'] = $db->select_query("SELECT * FROM ".TB_MEMBER_SECTION." WHERE section_id=".$arr['member']['section_id']."");	
	    $arr['member_section'] = $db->fetch($res['member_section']);	
	if($_SESSION['section_id']==0 OR $_SESSION['admin_level'] == 2){
	  $section_name = $agen_mini.$agen_name ;
	} else {
	  $res['section'] = $db->select_query("SELECT * FROM ".TB_MEMBER_SECTION." WHERE section_id='".$_SESSION['section_id']."' ");
	  $arr['section'] = $db->fetch($res['section']);
	  $section_name = $arr['section']['section_name'] ;
    }			
		
?>

<div id="pCalendar" style="position: absolute; left: 10px; top: 10px; visibility: hidden;"></div>     
<table width="100%" border="0" cellpadding="2" cellspacing="3" >
<form NAME="myform" METHOD="post" ACTION="?folder=material&file=requistion&op=requist_form&action=add_ok">
  <tr>
    <td width="30" height="20" ></td>
    <td colspan="3">
	<input type="hidden" name="sh_id" id="sh_id" value="<?php echo $sh_id ; ?>"> 
	<input type="hidden" name="shf_id" id="shf_id" value="<?php echo $shf_id ; ?>">
	<input type="hidden" name="sd_price" id="sd_price" value="<?php echo $arr['stock_head_form']['shf_price']; ?>">
	<input type="hidden" name="sd_note" id="sd_note" value="">
	<input type="hidden" name="sh_name" id="sh_name" value="<?php echo $_POST['sh_name']; ?>">
	<input type="hidden" name="section_id" id="section_id" value="<?php echo $arr['member']['section_id']; ?>">
	</td>
  </tr>
  <tr height="30">
    <td></td>
    <td rowspan="7" align="center" valign="top" width="100"><img src="images/material/stock/watsadu.png" width="100" height="75" border="0" /></td>
    <td align="right" class="requist_form_title">ชื่อผู้เบิก :</td>
    <td class="requist_form"><?php echo $sd_name ;?>&nbsp;&nbsp;&nbsp;<?php  echo "  (ส่วน/กอง :".$arr['member_section']['section_name'].")" ;?>
	<input type="hidden" name="sd_name" id="sd_name" value="<?php echo $sd_name ; ?>" >
	</td>
  </tr>
  <tr height="30">
    <td></td>
    <td align="right" class="requist_form_title">หน่วยงาน :</td>
    <td class="requist_form"><?php  echo $section_name ;?>
	</td>
  </tr>  
  <tr height="30">
    <td></td>
    <td align="right" class="requist_form_title">เบิกวันที่ :</td>
    <td class="requist_form"><?php  echo $day." ".$month." ".$year ;?>
	<input type="hidden" name="sd_date" id="sd_date" value="<?php echo $sd_date ; ?>" >
	</td>
  </tr>
  <tr height="30">
    <td>&nbsp;</td>
    <td align="right" class="requist_form_title">ราคา / ขนาดหรือลลักษณะ :</td>
    <td class="requist_form"><?php  echo $arr['stock_head_form']['shf_price']." บาท  / ".$arr['stock_head_form']['shf_diff_name']."" ;?></td>
  </tr>  
  <tr height="30">
    <td>&nbsp;</td>
    <td align="right" class="requist_form_title">จำนวนที่มีอยู่ :</td>
    <td class="requist_form"><?php  echo $arr['stock_head_form']['shf_amountcost']."  ".$arr['stock_head_form']['shf_unit']."&nbsp;&nbsp;".$sh_unit ;?></td>
  </tr>
  <tr height="30">
	<td></td>
    <td align="right" class="requist_form_title">เบิกจำนวน :</td>
    <td class="requist_form"><?php  echo $sd_amount."&nbsp;&nbsp;".$sh_unit ;?>
	<input type="hidden" name="sd_amount" id="sd_amount" value="<?php echo $sd_amount ; ?>" >
	</td>
  </tr>  
  <tr height="30">
	<td></td>
    <td align="right" class="requist_form_title">รวมเป็นเงิน :</td>
    <td class="requist_form"><?php  echo  $arr['stock_head_form']['shf_price']*$sd_amount ;?>
<!--	<input type="hidden" name="sd_amount" id="sd_amount" value="<?php //echo $sd_amount ; ?>" > -->
	</td>
  </tr>   
  <tr height="30">
    <td></td>
    <td class="requist_form"><?php  echo $sh_name ;?></td>
    <td align="right" class="requist_form_title">จำนวนคงเหลือ :</td>
    <td class="requist_form"><?php  echo $shf_amountcost."&nbsp;&nbsp;".$sh_unit ;?>
	<input type="hidden" name="shf_amountcost" id="shf_amountcost" value="<?php echo $shf_amountcost ; ?>" >
	</td>
  </tr>  
  <tr height="40">
    <td colspan="4"></td>
  </tr>
  <tr>
    <td colspan="4" align="center" valign="top"><center>
         <input type="submit" name="button" id="button" value=" ยืนยันการเบิก  " /> 
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <input type="reset" name="button2" id="button2" value=" กลับไปแก้ไขใหม่ " />
    </center></td>
  </tr>
  </form>
</table>
<?php 

} else if($op == "requist_form") {

$w=$thai_w[date("w")];
$d=date("d");
$n=$SHORT_MONTH[date("n")];
$m=date("n");
$y=date("Y") +543;
$ye=date("Y");

$date_hid=$ye."-".$m."-".$d ;
    
	$db->connectdb(DB_NAME,DB_USERNAME,DB_PASSWORD);
    $res['stock_head'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD." WHERE sh_id=".$_GET['sh_id']."");
    $arr['stock_head'] = $db->fetch($res['stock_head']) ;
    $res['stock_head_form'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD_PRICE." WHERE sh_id=".$arr['stock_head']['sh_id']."");	
    $res['head_from_amountcost'] = $db->select_query("SELECT SUM(shf_amountcost) AS amountcost  FROM ".TB_STOCK_HEAD_PRICE." WHERE sh_id=".$arr['stock_head']['sh_id']."");
	$arr['head_from_amountcost'] = $db->fetch($res['head_from_amountcost']);	
?>

<script language="javascript" type="text/javascript">
function  print_acc_Open(sh_id) {
window.open("?folder=material&file=print_acc_see&sh_id="+sh_id+"","","toolbar=no,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=950,height=680,left=5,top=5"); 
} 
</script>

<script type="text/javascript"  src="js/calender.js"></script>
<div id="pCalendar" style="position: absolute; left: 10px; top: 10px; visibility: hidden;"></div>     
<table width="100%" border="0" cellpadding="2" cellspacing="3" >
<form NAME="myform" METHOD="post" ACTION="?folder=material&file=requistion&op=requist_form&action=add">
  <tr>
    <td width="15" height="20" ></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
<?php 
        if(empty($admin_user) and isset($login_true)) {
		$res['member'] = $db->select_query("SELECT member_id, prefix, fname, lname FROM ".TB_MEMBER." WHERE user='".$login_true."' ");
		$arr['member'] = $db->fetch($res['member']);
?>  
  <tr height="30">
    <td></td>
    <td rowspan="3" align="center" valign="top" ><img src="images/material/stock/watsadu.png" width="100" height="75" border="0" /></td>
    <td align="right" class="requist_form_title">ชื่อผู้เบิก :</td>
    <td class="requist_form"><?php echo $arr['member']['prefix'];?><?php echo $arr['member']['fname'];?>&nbsp;<?php echo $arr['member']['lname'];?></td>
    <input type="hidden" name="member_id" id="member_id" value="<?php echo $arr['member']['member_id'] ;?>">
  </tr>
<?php 
        } else  if(isset($admin_user) and empty($login_true)) {
if($arr['stock_head']['section_id'] == 0) {
		$res['member'] = $db->select_query("SELECT member_id, fname, lname FROM ".TB_MEMBER." WHERE parties_id ='4' ORDER BY section_id, level ");
} else {
		$res['member'] = $db->select_query("SELECT member_id, fname, lname FROM ".TB_MEMBER." WHERE parties_id ='4' AND section_id = ".$arr['stock_head']['section_id']." ORDER BY level ");
}				
?>  
  <tr height="30">
    <td></td>
    <td rowspan="4" align="center" valign="top" ><img src="images/material/stock/watsadu.png" width="100" height="75" border="0" /></td>
    <td align="right" class="requist_form_title">ชื่อผู้เบิก :</td>
    <td class="requist_form"><select name="member_id" id="member_id" ><option value="" select>--เลือกผู้เบิก--</option>
	 <?php 
	 while($arr['member'] = $db->fetch($res['member'])){
               echo "<option value='".$arr['member']['member_id']."' >".$arr['member']['fname']."&nbsp;".$arr['member']['lname']."</option> \n" ;
          }	
	 ?>	  
	</td>
  </tr>
<?php 
        }
	if($arr['stock_head']['section_id'] == 0){
	  $section_name = $agen_mini.$agen_name ;
	} else {
	  $res['section'] = $db->select_query("SELECT * FROM ".TB_MEMBER_SECTION." WHERE section_id='".$arr['stock_head']['section_id']."' ");
	  $arr['section'] = $db->fetch($res['section']);
	  $section_name = $arr['section']['section_name'] ;
    }		
		
?>
  <tr height="30">
    <td></td>
    <td align="right" class="requist_form_title">หน่วยงาน :</td>
    <td><b><?php echo $section_name ;?></b></td>
  </tr>
  <tr height="30">
    <td></td>
    <td align="right" class="requist_form_title">วันที่ :</td>
    <td><IMG SRC="images/dateselect.gif" BORDER="0" ALT="เลือกวันที่" onClick="showCalendar(this,1)" align="absmiddle">&nbsp;
	<input name="tCalendar_1" type="text" id="tCalendar_1" size="14" value="" class="requist_form" ><?php // echo "$d $n $y" ;?>
	<br><input type="hidden" name="sh_date_1" id="sh_date_1" value="<?php echo $date_hid ;?>">
	</td>
  </tr>
  <tr height="30">
    <td>&nbsp;</td>
    <td align="right" class="requist_form_title">จำนวนเหลือ (ราคา) ขนาดหรือลักษณะ:</td>
    <td>
        <select name="shf_id" id="shf_id" class="requist_form">
		<?php  while($arr['stock_head_form'] = $db->fetch($res['stock_head_form'])){ 
		   if($arr['stock_head_form']['shf_amountcost']<>'0') {
           echo "<option value=".$arr['stock_head_form']['shf_id']." > ".$arr['stock_head_form']['shf_amountcost']."&nbsp;(".$arr['stock_head_form']['shf_price']." บาท) ".$arr['stock_head_form']['shf_diff_name']."</option>" ;
           }
		}?>
		</select><b><?php echo $arr['stock_head']['sh_unit'] ;?></b>
   </td>
  </tr>
  <tr height="30">
    <td></td>
    <td align="center"><font color="#999999" size="2"><b><?php echo $arr['head_from_amountcost']['amountcost'] ;?>&nbsp;&nbsp;<?php echo $arr['stock_head']['sh_unit'] ;?></b></font>
	<br><font color="#FF0000" size="3"><b><?php echo $arr['stock_head']['sh_name'] ;?></b></font><br>
	<?php echo $arr['stock_head']['sh_diff_name'] ;?>
	</td>
    <td align="right" class="requist_form_title">เบิกจำนวน :</td>
    <td><input type="text" size="10" value="" name="sd_amount" id="sd_amount" style="text-align:center;" class="requist_form" />
	 <b><?php echo $arr['stock_head']['sh_unit'] ;?></b>
	</td>
  </tr>  
  <tr height="40">
    <td colspan="4"><input type="hidden" name="sh_id" id="sh_id" value="<?php echo $arr['stock_head']['sh_id'] ;?>">
    <input type="hidden" name="sh_name" id="sh_name" value="<?php echo $arr['stock_head']['sh_name'] ;?>">
	<input type="hidden" name="sh_unit" id="sh_unit" value="<?php echo $arr['stock_head']['sh_unit'] ;?>">
	</td>
  </tr>
  <tr>
    <td colspan="4" align="center" valign="top"><center>
         <input type="submit" name="button" id="button" value="  ตกลง   " /> 
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <input type="reset" name="button2" id="button2" value="  เครีย   " />
    </center></td>
  </tr>
  <tr>
    <td width="15" height="30" ></td>
    <td><input type="button" onClick="print_acc_Open(<?php echo $arr['stock_head']['sh_id'];?>)" value="ดูบัญชีวัสดุ <?php echo $arr['stock_head']['sh_name'];?>"></td>
    <td></td>
    <td></td>
  </tr>  
  </form>
</table>
<script language="JavaScript">
dtNow = new Date();
makeCalendar(dtNow.getMonth(), dtNow.getFullYear());
</script>
<?php 
} else if($ProcessOutput) {
	echo $ProcessOutput ;
}	
    echo "<br><br>" ;
?>