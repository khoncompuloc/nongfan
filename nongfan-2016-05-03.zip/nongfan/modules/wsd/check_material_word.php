﻿<?
header("Content-Type: application/ms-word");
header('Content-Disposition: attachment; filename="filename.doc"');
?> 
<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-874">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 11">
<meta name=Originator content="Microsoft Word 11">
<link rel=File-List href="check_material_word.files/filelist.xml">
<title></title>
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>naivoi</o:Author>
  <o:LastAuthor>HomeUser</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>39</o:TotalTime>
  <o:Created>2012-11-17T06:32:00Z</o:Created>
  <o:LastSaved>2012-11-17T06:32:00Z</o:LastSaved>
  <o:Pages>1</o:Pages>
  <o:Words>31</o:Words>
  <o:Characters>183</o:Characters>
  <o:Lines>1</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>213</o:CharactersWithSpaces>
  <o:Version>11.6568</o:Version>
 </o:DocumentProperties>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:ApplyBreakingRules/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
  </w:Compatibility>
  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="156">
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Angsana New";
	panose-1:2 2 6 3 5 4 5 2 3 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:16777219 0 0 0 65537 0;}
@font-face
	{font-family:"TH SarabunPSK";
	panose-1:2 11 5 0 4 2 0 2 0 3;
	mso-font-alt:"Arial Unicode MS";
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-1593835409 1342185562 0 0 65923 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	mso-bidi-font-size:14.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Angsana New";}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
@page Section1
	{size:595.3pt 841.9pt;
	margin:18.0pt 10.3pt 9.0pt 36.0pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:ตารางปกติ;
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-ansi-language:#0400;
	mso-fareast-language:#0400;
	mso-bidi-language:#0400;}
table.MsoTableGrid
	{mso-style-name:เส้นตาราง;
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	border:solid windowtext 1.0pt;
	mso-border-alt:solid windowtext .5pt;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid windowtext;
	mso-border-insidev:.5pt solid windowtext;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-ansi-language:#0400;
	mso-fareast-language:#0400;
	mso-bidi-language:#0400;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="2050"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
 <?
    // $limit = 25 ;
	//$res['count_page'] = $db->select_query("SELECT COUNT(sh_id) AS num_page FROM ".TB_STOCK_HEAD."");	
    //$arr['count_page'] = $db->fetch($res['count_page']);
	// $page = ceil($arr['count_page']['num_page']/$limit) ;
 ?>
 
</head>

<body lang=EN-US style='tab-interval:36.0pt'>
<?
//for($i=1;$i<=$page;$i++) { 
//    $limit_start = ($i-1)*$limit ;
    $res['stock_head'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD." ORDER BY sh_id ");	//LIMIT $limit_start, $limit 
?>	
<div class=Section1>
<p class=MsoNormal align=center style='text-align:center'><b><span
style='font-size:16.0pt;font-family:"TH SarabunPSK"'>สรุปยอดวัสดุคงเหลือ</span></b></p>
<p class=MsoNormal align=center style='text-align:center'><b><span
style='font-size:8.0pt;font-family:"TH SarabunPSK"'>&nbsp;</span></b></p>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=735
 style='width:551.1pt;border-collapse:collapse;border:none;mso-border-alt:solid windowtext .5pt;
 mso-yfti-tbllook:480;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 .5pt solid windowtext;mso-border-insidev:.5pt solid windowtext'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=79 valign=top style='width:59.4pt;border:solid windowtext 1.0pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>รหัส</span></b></p>
  </td>
  <td width=216 valign=top style='width:162.0pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>ชื่อหรือชนิด
  (ขนาด/ลักษณะ)</span></b></p>
  </td>
  <td width=108 valign=top style='width:81.0pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>ประเภท</span></b></p>
  </td>
  <td width=216 valign=top style='width:162.0pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>ขนาด-ลักษณะ/ราคา/จำนวน</span></b></p>
  </td>
  <td width=51 valign=top style='width:38.4pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>จำนวน</span></b></p>
  </td>
  <td width=64 valign=top style='width:48.3pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='text-align:center'><b><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'>หมายเหตุ</span></b></p>
  </td>
 </tr>
 <?
 while($arr['stock_head'] = $db->fetch($res['stock_head'])){

    empty($arr['stock_head']['sh_diff_name'])?$sh_diff_name="":$sh_diff_name=" ( ".$arr['stock_head']['sh_diff_name']." )" ;
	$res['stock_type'] = $db->select_query("SELECT * FROM ".TB_STOCK_TYPE." WHERE type_id='".$arr['stock_head']['type_id']."' ");
	$arr['stock_type'] = $db->fetch($res['stock_type']);
	$res['stock_subtype'] = $db->select_query("SELECT * FROM ".TB_STOCK_SUBTYPE." WHERE subtype_id='".$arr['stock_head']['subtype_id']."' ");
	$arr['stock_subtype'] = $db->fetch($res['stock_subtype']);	
	empty($arr['stock_subtype']['subtype_name'])?$subtype_name=" - ทั่วไป":$subtype_name=" - ".$arr['stock_subtype']['subtype_name']."" ;
    $res['head_from_amountcost'] = $db->select_query("SELECT SUM(shf_amountcost) AS amountcost  FROM ".TB_STOCK_HEAD_PRICE." WHERE sh_id=".$arr['stock_head']['sh_id']."");
	$arr['head_from_amountcost'] = $db->fetch($res['head_from_amountcost']);	
	$res['stock_head_from'] = $db->select_query("SELECT * FROM ".TB_STOCK_HEAD_PRICE." WHERE sh_id=".$arr['stock_head']['sh_id']."");
	?>
 <tr style='mso-yfti-irow:1;height:18.65pt'>
  <td width=79 valign=top style='width:59.4pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <p class=MsoNormal align=center style='text-align:center'><span lang=TH
  style='font-size:14.0pt;font-family:"TH SarabunPSK"'><?echo $arr['stock_head']['sh_code_id'];?></span></p>
  </td>
  <td width=216 valign=top style='width:162.0pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <p class=MsoNormal><span lang=TH style='font-size:13.0pt;font-family:"TH SarabunPSK"'>
  <?echo $arr['stock_head']['sh_name'];?><?echo $sh_diff_name; ?></span></p>
  </td>
  <td width=108 valign=top style='width:81.0pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <p class=MsoNormal><span lang=TH style='font-size:13.0pt;font-family:"TH SarabunPSK"'>
  <?=$arr['stock_type']['type_name'] ;?></span></p>
  </td>
  <td width=216 valign=top style='width:162.0pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <?
  while($arr['stock_head_from'] = $db->fetch($res['stock_head_from'])){ 
  empty($arr['stock_head_from']['shf_diff_name'])?$shf_diff_name=" - ":$shf_diff_name=" - ".$arr['stock_head_from']['shf_diff_name']."" ;  
  ?>
  <p class=MsoNormal><span
  style='font-size:13.0pt;font-family:"TH SarabunPSK"'>
  <?=$shf_diff_name ;?>/<?=$arr['stock_head_from']['shf_price'];?>/<?=$arr['stock_head_from']['shf_amountcost'];?>
  </span></p>
  <?  }  ?> 
  </td>
  <td width=51 valign=top style='width:38.4pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <p class=MsoNormal><b><span
  style='font-size:16.0pt;font-family:"TH SarabunPSK"'>
  <?=$arr['head_from_amountcost']['amountcost'] ;?></span></b>&nbsp;&nbsp;<span
  style='font-size:13.0pt;font-family:"TH SarabunPSK"'><?=$arr['stock_head']['sh_unit'] ;?></span></p>
  </td>
  <td width=64 valign=top style='width:48.3pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:18.65pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:13.0pt;font-family:"TH SarabunPSK"'>&nbsp;</span></p>
  </td>
 </tr>
 <?
 }
 ?>
</table>
<p class=MsoNormal align=center style='text-align:center'><b><span
style='font-size:16.0pt;font-family:"TH SarabunPSK"'>&nbsp;</span></b></p>
</div>
<? 
//}
?>
</body>
</html>